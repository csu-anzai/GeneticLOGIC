

#include <stdio.h>

#include "pixmon.h"


int main(argc, argv)
int argc;
char *argv[];
{
	char command[256];
	ImgHdr hdr;
	unsigned char color;
	FILE *pix;

	INIT_IMGHDR(hdr);

	hdr.dy = hdr.dx = 1;
	hdr.y = 0;
	hdr.sizehi = 0;
	hdr.sizelo = 1;

	sprintf(command,"pixmon -dx 256 -dy 1 -width 256 -height 50 %s%s",  
		argc >= 2 && strcmp(argv[1], "dither") == 0 ? "-" : "-cmap ", 
		argc < 2 ? "default" : argv[1]);
	pix = popen(command,"w");

	for (hdr.x = 0; hdr.x < 256; hdr.x++) {
		color = (unsigned char) hdr.x;
		fwrite(&hdr, sizeof(hdr),1,pix);
		fwrite(&color, 1, 1, pix);
		fflush(pix);
	}
	EXIT_IMGHDR(hdr);
	fwrite(&hdr, sizeof(hdr),1,pix);

	pclose(pix);
	exit(0);
}
