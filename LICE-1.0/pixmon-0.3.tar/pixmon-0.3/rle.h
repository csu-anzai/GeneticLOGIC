#ifdef __STDC__

extern
unsigned long 
rl_encode(
	unsigned char	*buffer, 
	unsigned long	size, 
	unsigned char	escape
);

extern
unsigned long 
rl_decode (
	unsigned char	*src_buffer, 
	unsigned char	*dst_buffer, 
	unsigned long	src_size, 
	unsigned char	escape
);

extern
unsigned long 
rl_decode_length (
	unsigned char	*src_buffer, 
	unsigned long	src_size, 
	unsigned char	escape
);

extern
void 
rl_decode_init(
		unsigned char	*src_buffer, 
		unsigned long	src_size,
		unsigned char	escape
);

extern
unsigned long 
rl_decode_next(
	        unsigned char	*dst_buffer, 
	        unsigned long	dst_size
);

#else

extern unsigned long rl_encode();
extern unsigned long rl_decode ();
extern unsigned long rl_decode_length ();
extern void rl_decode_init();
extern unsigned long rl_decode_next();

#endif
